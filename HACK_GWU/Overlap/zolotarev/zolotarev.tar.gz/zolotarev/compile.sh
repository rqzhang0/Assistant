gcc -o test elliptic.c invsqrt_zolotarev_coeff.c test.c -lm -std=c99
